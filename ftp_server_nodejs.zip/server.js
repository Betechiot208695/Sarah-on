const FtpSrv = require("ftp-srv");

const ftpServer = new FtpSrv({
  url: "ftp://0.0.0.0:2121",
  pasv_min: 1025,
  pasv_max: 1050,
  anonymous: false,
  greeting: ["Bienvenue sur ton FTP perso, mon amour 😘"]
});

const USER = "sarah";
const PASS = "damienlove";

ftpServer.on("login", ({ username, password }, resolve, reject) => {
  if (username === USER && password === PASS) {
    return resolve({ root: "./public" });
  }
  return reject(new Error("Identifiants invalides 💔"));
});

ftpServer.listen().then(() => {
  console.log("Serveur FTP lancé sur ftp://localhost:2121 🚀");
});
